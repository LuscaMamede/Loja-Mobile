class Constants {
  static const productBaseUrl =
      'https://shop-cod3r-c70a4-default-rtdb.firebaseio.com';
}
